

import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import ToDoList from './TodoList';
import ToDoForm from './ToDoForm';

function App() {
  const [tasks, setTasks] = useState([]);

  const addTask = (task) => {
    if (task !== '') { 
      setTasks([...tasks, task]); 
    }
  };

  return (
    <View style={styles.container}>
      <ToDoForm addTask={addTask} />
      <ToDoList tasks={tasks} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    paddingTop: 20,
    marginBottom: 240,
  },
});

export default App;